import React from 'react'

const HowToUse = () => {
  return (
    <div>HowToUse</div>
  )
}

export default HowToUse